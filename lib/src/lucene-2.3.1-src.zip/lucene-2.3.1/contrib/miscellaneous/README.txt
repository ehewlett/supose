contrib/miscellaneous is a home of different Lucene-related classes
that all belong to org.apache.lucene.misc package, as they are not
substantial enough to warrant their own package.
